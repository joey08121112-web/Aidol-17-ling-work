package com.vision.headsetdemo;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.StyleSpan;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.vision.headset.sdk.HeadsetManager;
import com.vision.headset.sdk.OnAuraTestEventListener;
import com.vision.headset.sdk.OnResultListener;
import com.vision.headset.sdk.entity.AuraTestEventEntity;
import com.vision.headset.sdk.entity.PowerEntity;
import com.vision.headset.sdk.enums.AuraTestEvent;
import com.vision.headset.sdk.enums.PositionType;
import com.vision.headset.sdk.util.AuraDevice;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/** Displays the events reported by Aura earbuds without replacing the connection listener. */
public class AuraKeyTestActivity extends Activity {
    private static final int MAX_EVENTS = 200;
    private static final long WEAR_QUERY_TIMEOUT_MS = 4000;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> events = new ArrayList<>();
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault());
    private ArrayAdapter<String> adapter;
    private String deviceMac;
    private boolean started;
    private boolean busy;
    private long operation;
    private long eventCount;
    private String statusMessage = "未注册监听";
    private OnAuraTestEventListener listener;
    private PositionType leftPosition;
    private PositionType rightPosition;
    private volatile long lifecycleGeneration;
    private volatile long wearQueryOperation;
    private Runnable wearQueryTimeout;

    private final OnResultListener<PowerEntity> wearListener = new OnResultListener<PowerEntity>() {
        @Override public void onResult(PowerEntity power) {
            final long lifecycle = lifecycleGeneration;
            final long request = wearQueryOperation;
            handler.post(() -> {
                if (!started || lifecycle != lifecycleGeneration || !deviceAvailable()
                        || power == null || !deviceMac.equalsIgnoreCase(power.getMac())
                        || !power.hasAttribute(PowerEntity.ATTR_POSITION)) return;
                leftPosition = power.getLeftPosition();
                rightPosition = power.getRightPosition();
                updateWearState();
                if (request == 0 || wearQueryOperation != request || operation != request) return;
                cancelWearQuery();
                if (leftPosition != PositionType.InEar || rightPosition != PositionType.InEar) {
                    busy = false;
                    statusMessage = "未注册监听 · 请先佩戴双耳耳机";
                    Toast.makeText(AuraKeyTestActivity.this,
                            "请先佩戴双耳耳机，再注册监听", Toast.LENGTH_SHORT).show();
                    updateControls();
                    return;
                }
                beginRegistration(request);
            });
        }

        @Override public void onError(int code, String message) {
            final long lifecycle = lifecycleGeneration;
            final long request = wearQueryOperation;
            handler.post(() -> {
                if (!started || lifecycle != lifecycleGeneration || request == 0
                        || wearQueryOperation != request || operation != request) return;
                finishWearQuery("佩戴状态查询失败，请重试");
            });
        }
    };

    private final Runnable refreshState = new Runnable() {
        @Override public void run() {
            if (!started) return;
            if (!deviceAvailable()) {
                OnAuraTestEventListener previous = listener;
                listener = null;
                if (previous != null || busy) operation++;
                cancelWearQuery();
                busy = false;
                leftPosition = null;
                rightPosition = null;
                updateWearState();
                statusMessage = "未注册监听 · 连接恢复后可重新注册";
                if (previous != null) HeadsetManager.unregisterAuraTestEventListener(previous, null);
            }
            updateControls();
            handler.postDelayed(this, 500);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aura_key_test);
        deviceMac = HeadsetManager.getConnectedDeviceMac();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, events);
        ((ListView) findViewById(R.id.aura_test_events)).setAdapter(adapter);
        ((TextView) findViewById(R.id.aura_test_device)).setText("设备 MAC：" + deviceMac);
        ((TextView) findViewById(R.id.aura_test_supported_events)).setText(supportedEventsText());
        updateWearState();
        updateCount();
    }

    @Override protected void onStart() {
        super.onStart();
        started = true;
        lifecycleGeneration++;
        leftPosition = null;
        rightPosition = null;
        updateWearState();
        statusMessage = "未注册监听";
        HeadsetManager.addAuraPowerListener(wearListener);
        if (deviceAvailable()) HeadsetManager.refreshAuraPower();
        handler.post(refreshState);
    }

    @Override protected void onStop() {
        started = false;
        lifecycleGeneration++;
        operation++;
        cancelWearQuery();
        HeadsetManager.removeAuraPowerListener(wearListener);
        handler.removeCallbacks(refreshState);
        OnAuraTestEventListener previous = listener;
        listener = null;
        busy = false;
        // Registration may still be awaiting a device response; always cancel this listener.
        if (previous != null) HeadsetManager.unregisterAuraTestEventListener(previous, null);
        super.onStop();
    }

    private boolean deviceAvailable() {
        return HeadsetManager.isDeviceReady()
                && HeadsetManager.getConnectedDeviceType() == AuraDevice.EARBUDS
                && deviceMac != null && deviceMac.equalsIgnoreCase(HeadsetManager.getConnectedDeviceMac());
    }

    private boolean isRegistered() {
        return listener != null && HeadsetManager.isAuraTestEventListenerRegistered(listener);
    }

    private void updateControls() {
        boolean available = deviceAvailable();
        boolean registered = isRegistered();
        String state = !available ? "设备已断开或切换，请返回主页连接 Aura 耳机" : statusMessage;
        ((TextView) findViewById(R.id.aura_test_status)).setText(state);
        findViewById(R.id.aura_test_register).setEnabled(started && available && !busy && !registered);
        findViewById(R.id.aura_test_unregister).setEnabled(started && available && !busy && registered);
        findViewById(R.id.aura_test_clear).setEnabled(!busy);
    }

    public void registerEvents(View view) {
        if (!started || busy || !deviceAvailable() || isRegistered()) return;
        final long request = ++operation;
        wearQueryOperation = request;
        busy = true;
        statusMessage = "正在检测双耳佩戴状态…";
        updateControls();
        wearQueryTimeout = () -> {
            if (!started || operation != request || wearQueryOperation != request) return;
            finishWearQuery("未获取到佩戴状态，请重试");
        };
        handler.postDelayed(wearQueryTimeout, WEAR_QUERY_TIMEOUT_MS);
        if (!HeadsetManager.refreshAuraPower()) {
            finishWearQuery("暂时无法检测佩戴状态，请重试");
        }
    }

    private void cancelWearQuery() {
        wearQueryOperation = 0;
        if (wearQueryTimeout != null) handler.removeCallbacks(wearQueryTimeout);
        wearQueryTimeout = null;
    }

    private void finishWearQuery(String message) {
        cancelWearQuery();
        busy = false;
        statusMessage = "未注册监听 · " + message;
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        updateControls();
    }

    private void beginRegistration(final long request) {
        // Each attempt owns its listener, so an old callback cannot cancel a newer attempt.
        final OnAuraTestEventListener requestedListener = new OnAuraTestEventListener() {
            @Override public void onEvent(AuraTestEventEntity event) {
                handler.post(() -> {
                    if (!started || listener != this || !deviceAvailable() || !isRegistered()) return;
                    appendEvent(event);
                });
            }

            @Override public void onError(int code, String message) {
                handler.post(() -> {
                    if (!started || listener != this) return;
                    operation++;
                    listener = null;
                    busy = false;
                    statusMessage = "监听已停止：" + message + " (" + code + ")";
                    HeadsetManager.unregisterAuraTestEventListener(this, null);
                    updateControls();
                });
            }
        };
        listener = requestedListener;
        busy = true;
        statusMessage = "正在注册监听…";
        updateControls();
        HeadsetManager.registerAuraTestEventListener(requestedListener, new OnResultListener<Void>() {
            @Override public void onResult(Void ignored) {
                handler.post(() -> {
                    if (!started || operation != request || listener != requestedListener) {
                        HeadsetManager.unregisterAuraTestEventListener(requestedListener, null);
                        return;
                    }
                    busy = false;
                    statusMessage = isRegistered() ? "已注册监听 · 等待耳机事件" : "未注册监听";
                    updateControls();
                });
            }

            @Override public void onError(int code, String message) {
                handler.post(() -> {
                    if (!started || operation != request || listener != requestedListener) return;
                    busy = false;
                    listener = null;
                    statusMessage = "注册失败：" + message + " (" + code + ")";
                    HeadsetManager.unregisterAuraTestEventListener(requestedListener, null);
                    updateControls();
                });
            }
        });
    }

    public void unregisterEvents(View view) {
        if (!started || busy || !isRegistered()) return;
        final long request = ++operation;
        final OnAuraTestEventListener requestedListener = listener;
        busy = true;
        statusMessage = "正在反注册监听…";
        updateControls();
        HeadsetManager.unregisterAuraTestEventListener(requestedListener, new OnResultListener<Void>() {
            @Override public void onResult(Void ignored) {
                finish("已反注册监听", true);
            }

            @Override public void onError(int code, String message) {
                finish("反注册失败：" + message + " (" + code + ")", false);
            }

            private void finish(String message, boolean success) {
                handler.post(() -> {
                    if (!started || operation != request || listener != requestedListener) return;
                    busy = false;
                    if (success || !isRegistered()) listener = null;
                    statusMessage = message;
                    updateControls();
                });
            }
        });
    }

    public void clearEvents(View view) {
        if (busy) return;
        events.clear();
        eventCount = 0;
        adapter.notifyDataSetChanged();
        updateCount();
    }

    public void toggleSupportedEvents(View view) {
        View content = findViewById(R.id.aura_test_supported_scroll);
        boolean expanded = content.getVisibility() != View.VISIBLE;
        content.setVisibility(expanded ? View.VISIBLE : View.GONE);
        ((TextView) view).setText(expanded ? "支持事件（收起）" : "支持事件（展开）");
    }

    private CharSequence supportedEventsText() {
        SpannableStringBuilder text = new SpannableStringBuilder();
        appendEventGroup(text, "按捏：捏耳机柄后松开，可连续按捏",
                AuraTestEvent.PRESS_SINGLE_CLICK, AuraTestEvent.PRESS_DOUBLE_CLICK,
                AuraTestEvent.PRESS_TRIPLE_CLICK, AuraTestEvent.PRESS_QUADRUPLE_CLICK,
                AuraTestEvent.PRESS_QUINTUPLE_CLICK);
        appendEventGroup(text, "捏住：持续捏住耳机柄，不松手", AuraTestEvent.PRESS_LONG_PRESS);
        appendEventGroup(text, "敲击：轻敲 Logo 区域",
                AuraTestEvent.CAP_SINGLE_CLICK, AuraTestEvent.CAP_DOUBLE_CLICK,
                AuraTestEvent.CAP_TRIPLE_CLICK);
        appendEventGroup(text, "长按：按住 Logo 区域，松手结束",
                AuraTestEvent.CAP_SHORT_PRESS, AuraTestEvent.CAP_LONG_PRESS,
                AuraTestEvent.CAP_RELEASE);
        appendEventGroup(text, "滑动：沿耳机柄滑动",
                AuraTestEvent.CAP_SLIDE_FORWARD, AuraTestEvent.CAP_SLIDE_BACKWARD);
        appendEventGroup(text, "头部动作：佩戴耳机后操作",
                AuraTestEvent.HEAD_GESTURE_YES, AuraTestEvent.HEAD_GESTURE_NO);
        return text;
    }

    private void appendEventGroup(SpannableStringBuilder text, String instruction, AuraTestEvent... events) {
        if (text.length() > 0) text.append("\n\n");
        int titleStart = text.length();
        text.append(instruction);
        text.setSpan(new StyleSpan(Typeface.BOLD), titleStart, text.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        text.append('\n');
        for (int index = 0; index < events.length; index++) {
            if (index > 0) text.append("、");
            text.append(events[index].getDisplayName());
        }
    }

    private void updateWearState() {
        ((TextView) findViewById(R.id.aura_test_wear)).setText("佩戴状态：左耳 "
                + positionLabel(leftPosition) + " · 右耳 " + positionLabel(rightPosition));
    }

    private String positionLabel(PositionType position) {
        if (position == PositionType.InEar) return "已佩戴";
        if (position == PositionType.InCase) return "入盒";
        if (position == PositionType.OutCase) return "盒外未佩戴";
        return "未知";
    }

    private void appendEvent(AuraTestEventEntity event) {
        if (event == null) return;
        eventCount++;
        String text = "#" + eventCount + "  " + timeFormat.format(new Date(event.getTimestamp()))
                + "\n" + event.getEvent().getDisplayName();
        events.add(0, text);
        if (events.size() > MAX_EVENTS) events.remove(events.size() - 1);
        adapter.notifyDataSetChanged();
        ((ListView) findViewById(R.id.aura_test_events)).setSelection(0);
        updateCount();
    }

    private void updateCount() {
        ((TextView) findViewById(R.id.aura_test_count)).setText("已收到 " + eventCount
                + " 个事件 · 显示最近 " + events.size() + " 条（最多 " + MAX_EVENTS + " 条）");
    }
}
