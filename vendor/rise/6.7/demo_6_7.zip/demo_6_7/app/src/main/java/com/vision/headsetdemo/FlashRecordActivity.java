package com.vision.headsetdemo;

import android.app.Activity;
import android.app.AlertDialog;
import android.view.ViewGroup;
import com.vision.headset.sdk.bean.TagCollectionData;
import com.vision.headset.sdk.bean.TagCollectionResponse;
import com.vision.headset.sdk.core.model.gaia.TagCollectionCodec;
import com.vision.headset.sdk.util.AuraDevice;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.vision.headset.sdk.HeadsetManager;
import com.vision.headset.sdk.HeadsetErrorCode;
import com.vision.headset.sdk.OnResultListener;
import com.vision.headset.sdk.entity.FlashRecordDeleteEntity;
import com.vision.headset.sdk.entity.FlashRecordDownloadCheckEntity;
import com.vision.headset.sdk.entity.FlashRecordEntity;
import com.vision.headset.sdk.entity.FlashRecordInfoEntity;
import com.vision.headset.sdk.entity.FlashRecordListEntity;
import com.vision.headset.sdk.entity.FlashRecordStateEntity;
import com.vision.headset.sdk.entity.FlashRecordStopEntity;
import com.vision.headset.sdk.entity.RecordDataEntity;
import com.vision.headset.sdk.util.AudioTracker;
import com.vision.headsetdemo.adapter.FlashRecordAdapter;
import com.vision.headsetdemo.util.DemoLog;
import com.vision.headsetdemo.util.FileUtil;

import java.io.File;
import java.util.ArrayList;
import java.util.List;


/**
 * Copyright (C), Vision Intelligence
 * FileName: FlashRecordActivity
 * Author: 毛神
 * Date: 2025/11/5 10:36
 * Description: demo页面
 * History:
 * 调整为通话录音示例
 */
public class FlashRecordActivity extends Activity {
    private static final String TAG = "FlashRecordActivity";
    private AudioTracker playback;
    private ScrollView mScrollView;
    private TextView mResultTv;

    private ListView mRecordListViewLeft;
    private ListView mRecordListViewRight;

    private FlashRecordAdapter mAdapterLeft;
    private FlashRecordAdapter mAdapterRight;

    private List<FlashRecordEntity> mRecordListLeft = new ArrayList<>();
    private List<FlashRecordEntity> mRecordListRight = new ArrayList<>();

    // 缓存选中的记录index，用于删除功能
    private Integer mSelectedIndexLeft = null; // 左耳选中的index
    private Integer mSelectedIndexRight = null; // 右耳选中的index

    public String mRecordPath = "";

    private FlashRecordStateEntity mCurrentState = null;
    private String deviceMac;
    private TagCollectionResponse selectedTag;
    private boolean tagBusy;
    private boolean downloading;
    private boolean deviceAvailable() {
        if (isFinishing() || !HeadsetManager.isDeviceReady() || deviceMac == null || !deviceMac.equalsIgnoreCase(HeadsetManager.getConnectedDeviceMac())) {
            log("设备已断开或切换，请返回主页重新连接并进入闪录页"); return false;
        }
        return true;
    }
    private boolean canOperateTag() {
        if (!deviceAvailable()) return false;
        if (tagBusy || downloading || HeadsetManager.isFusionRecordBusy()) { log("请等待当前录音、下载或 TAG 操作完成"); return false; }
        return true;
    }
    private void tagBusy(boolean busy) {
        tagBusy = busy;
        setChildrenEnabled((ViewGroup) findViewById(R.id.tag_controls), !busy);
    }
    private void setChildrenEnabled(ViewGroup group, boolean enabled) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i); child.setEnabled(enabled);
            if (child instanceof ViewGroup) setChildrenEnabled((ViewGroup) child, enabled);
        }
    }
    private void clearTagSelection() { selectedTag = null; ((TextView) findViewById(R.id.tag_selection)).setText("TAG：先查询列表，再选择文件"); }
    public void queryLeftTags(View view) { queryTags(TagCollectionCodec.LEFT); }
    public void queryRightTags(View view) { queryTags(TagCollectionCodec.RIGHT); }
    private void queryTags(int ear) {
        if (!canOperateTag()) return;
        clearTagSelection(); tagBusy(true);
        HeadsetManager.getTagList(ear, new OnResultListener<List<TagCollectionResponse>>() {
            @Override public void onResult(List<TagCollectionResponse> files) {
                runOnUiThread(() -> {
                    tagBusy(false);
                    if (isFinishing()) return;
                    log((ear == TagCollectionCodec.LEFT ? "左耳" : "右耳") + " TAG 文件数: " + files.size());
                    if (files.isEmpty()) return;
                    String[] labels = new String[files.size()];
                    for (int i = 0; i < files.size(); i++) {
                        TagCollectionResponse file = files.get(i);
                        labels[i] = "文件 " + file.fileId + " · 索引 " + file.fileIndex + " · " + file.pointCount + " 个打点";
                    }
                    new AlertDialog.Builder(FlashRecordActivity.this).setTitle("选择 TAG 文件")
                            .setItems(labels, (dialog, position) -> {
                                selectedTag = files.get(position);
                                ((TextView) findViewById(R.id.tag_selection)).setText((ear == TagCollectionCodec.LEFT ? "左耳" : "右耳") + " TAG：" + labels[position]);
                            }).setNegativeButton("取消", null).show();
                });
            }
            @Override public void onError(int code, String message) { runOnUiThread(() -> { tagBusy(false); log("TAG 查询失败: " + message); }); }
        });
    }
    public void readSelectedTag(View view) {
        if (!canOperateTag()) return;
        if (selectedTag == null) { log("请查询 TAG 列表并选择文件"); return; }
        TagCollectionResponse file = selectedTag; tagBusy(true);
        HeadsetManager.readTagFile(file.ear, file.fileIndex, new OnResultListener<List<TagCollectionData.Point>>() {
            @Override public void onResult(List<TagCollectionData.Point> points) {
                StringBuilder text = new StringBuilder("TAG 文件 " + file.fileId + "，打点数 " + points.size() + "\n");
                for (TagCollectionData.Point point : points) text.append("TAG ").append(point.tagIndex).append(" · audioOffset=").append(point.audioOffset).append('\n');
                runOnUiThread(() -> { tagBusy(false); log(text.toString()); });
            }
            @Override public void onError(int code, String message) { runOnUiThread(() -> { tagBusy(false); clearTagSelection(); log("TAG 读取失败: " + message); }); }
        });
    }
    public void deleteSelectedTag(View view) {
        if (!canOperateTag()) return;
        if (selectedTag == null) { log("请查询 TAG 列表并选择文件"); return; }
        TagCollectionResponse file = selectedTag; tagBusy(true);
        HeadsetManager.deleteTagFile(file.ear, file.fileIndex, new OnResultListener<Void>() {
            @Override public void onResult(Void ignored) { runOnUiThread(() -> { tagBusy(false); clearTagSelection(); log("TAG 文件清除成功: " + file.fileId); queryTags(file.ear); }); }
            @Override public void onError(int code, String message) { runOnUiThread(() -> { tagBusy(false); clearTagSelection(); log("TAG 清除失败: " + message); }); }
        });
    }
    public void clearLeftTags(View view) { if (canOperateTag()) clearTags(TagCollectionCodec.LEFT, false); }
    public void clearRightTags(View view) { if (canOperateTag()) clearTags(TagCollectionCodec.RIGHT, false); }
    public void clearBothTags(View view) { if (canOperateTag()) clearTags(TagCollectionCodec.LEFT, true); }
    private void clearTags(int ear, boolean thenRight) {
        tagBusy(true); clearTagSelection();
        HeadsetManager.clearTags(ear, new OnResultListener<Void>() {
            private void finish(String result) {
                runOnUiThread(() -> {
                    log((ear == TagCollectionCodec.LEFT ? "左耳" : "右耳") + " TAG " + result);
                    tagBusy(false);
                    if (thenRight && !isFinishing() && deviceAvailable()) clearTags(TagCollectionCodec.RIGHT, false);
                });
            }
            @Override public void onResult(Void ignored) { finish("清空成功"); }
            @Override public void onError(int code, String message) { finish("清空失败: " + message); }
        });
    }
    @Override protected void onStop() {
        stopPlayback();
        super.onStop();
    }
    @Override protected void onDestroy() {
        stopPlayback();
        if (tagBusy) HeadsetManager.cancelTagRequest();
        if (downloading) HeadsetManager.cancelDownloadFlashRecord();
        HeadsetManager.registerFlashRecordStateListener(null);
        HeadsetManager.registerFlashRecordStopListener(null);
        super.onDestroy();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flash_record);
        mScrollView = findViewById(R.id.scroll_view);
        mResultTv = findViewById(R.id.result_tv);
        deviceMac = HeadsetManager.getConnectedDeviceMac();
        boolean box = HeadsetManager.getConnectedDeviceType() == AuraDevice.CASE;
        if (AuraDevice.isAura(deviceMac)) {
            ((TextView) findViewById(R.id.flash_delete_hint)).setText("(注：可选中任意闪录记录删除)");
        }
        findViewById(R.id.tag_controls).setVisibility(HeadsetManager.getConnectedDeviceType() == AuraDevice.EARBUDS ? View.VISIBLE : View.GONE);
        if (box) {
            // 盒子闪录页面仅保留空间查询入口。
            for (int id : new int[]{R.id.flash_list_headers, R.id.flash_record_lists,
                    R.id.flash_file_actions, R.id.flash_download_actions, R.id.flash_playback_actions,
                    R.id.flash_clear_actions, R.id.flash_clear_all_actions, R.id.flash_stop_button}) {
                findViewById(id).setVisibility(View.GONE);
            }
            ((Button) findViewById(R.id.flash_info_button)).setText("查询闪录空间");
            ViewGroup.LayoutParams controls = findViewById(R.id.flash_controls_scroll).getLayoutParams();
            controls.height = ViewGroup.LayoutParams.WRAP_CONTENT;
            findViewById(R.id.flash_controls_scroll).setLayoutParams(controls);
            android.widget.LinearLayout.LayoutParams logParams =
                    (android.widget.LinearLayout.LayoutParams) mScrollView.getLayoutParams();
            logParams.height = 0;
            logParams.weight = 1;
            mScrollView.setLayoutParams(logParams);
        }

        mRecordListViewLeft = findViewById(R.id.list_view_left);
        mRecordListViewRight = findViewById(R.id.list_view_right);

        mAdapterLeft = new FlashRecordAdapter(this, mRecordListLeft);
        mRecordListViewLeft.setAdapter(mAdapterLeft);
        mAdapterRight = new FlashRecordAdapter(this, mRecordListRight);
        mRecordListViewRight.setAdapter(mAdapterRight);

        // 设置左耳列表点击监听
        mRecordListViewLeft.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                handleItemClick(position, true);
            }
        });

        // 设置右耳列表点击监听
        mRecordListViewRight.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                handleItemClick(position, false);
            }
        });
        mRecordPath = getExternalCacheDir().getAbsolutePath() + "/flash_records/" + (deviceMac == null ? "unknown" : deviceMac.replace(":", "")) + "/";

        ///
        HeadsetManager.registerFlashRecordStateListener(new OnResultListener<FlashRecordStateEntity>() {
            @Override
            public void onResult(FlashRecordStateEntity flashRecordStateEntity) {
                log("Flash Record State: " + flashRecordStateEntity.toString());
                if (null != mCurrentState && mCurrentState.isRecording()) {
                    //之前处于录音状态
                    if (!flashRecordStateEntity.isRecording() && !AuraDevice.isCase(deviceMac)) {
                        //现在变为非录音状态，说明录音被停止，产生了一条新记录，这个时候，需要重新获取一次闪录列表，刷新页面
                        getFlashRecordList(null);
                    }
                }
                mCurrentState = flashRecordStateEntity;
            }

            @Override
            public void onError(int code, String msg) {
                log("Flash Record State Error: code=" + code + ", msg=" + msg);
            }
        });
        HeadsetManager.registerFlashRecordStopListener(new OnResultListener<FlashRecordStopEntity>() {
            @Override
            public void onResult(FlashRecordStopEntity entity) {
                log("Flash Record Stop: " + entity.toString());
            }

            @Override
            public void onError(int code, String msg) {
                log("Flash Record Stop Error: code=" + code + ", msg=" + msg);
            }
        });
    }

    public void getFlashRecordInfo(View view) {
        if (!deviceAvailable()) return;
        HeadsetManager.getFlashRecordInfo(new OnResultListener<FlashRecordInfoEntity>() {
            @Override
            public void onResult(FlashRecordInfoEntity flashRecordInfoEntity) {
                log("Flash Record Info: " + flashRecordInfoEntity.toString());
            }

            @Override
            public void onError(int code, String msg) {
                log("Get Flash Record Info Error: code=" + code + ", msg=" + msg);
            }
        });
    }

    public void stopCurrentFlashRecord(View view) {
        if (!deviceAvailable()) return;
        HeadsetManager.stopCurrentFlashRecord(new OnResultListener<Void>() {
            @Override
            public void onResult(Void result) {
                log(AuraDevice.isFamily(deviceMac) ? "设备已确认停止闪录" : "停止闪录成功");
            }

            @Override
            public void onError(int code, String msg) {
                log((code == HeadsetErrorCode.ERROR_TIMEOUT ? "停止闪录结果未确认" : "停止闪录失败") + ": code=" + code + ", " + msg);
            }
        });
    }

    public void getFlashRecordList(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        if (!deviceAvailable()) return;
        if (downloading || tagBusy) { log("请等待当前下载或 TAG 操作结束"); return; }
        HeadsetManager.getFlashRecordList(new OnResultListener<FlashRecordListEntity>() {
            @Override
            public void onResult(FlashRecordListEntity result) {
                List<FlashRecordEntity> recordList = result.getRecordList();
                log("Get Flash Record List Success: " + (result.isLeft() ? "Left" : "Right") + ": " + recordList.size());
                runOnUiThread(() -> {
                    if (result.isLeft()) {
                        mRecordListLeft.clear();
                        mRecordListLeft.addAll(recordList);
                        // 清除选中状态
                        mSelectedIndexLeft = null;
                        mAdapterLeft.clearSelection();
                        mAdapterLeft.notifyDataSetChanged();
                    } else {
                        mRecordListRight.clear();
                        mRecordListRight.addAll(recordList);
                        // 清除选中状态
                        mSelectedIndexRight = null;
                        mAdapterRight.clearSelection();
                        mAdapterRight.notifyDataSetChanged();
                    }
                });
            }

            @Override
            public void onError(int code, String msg) {
                log("Get Flash Record List Error: code=" + code + ", msg=" + msg);
            }
        });
    }

    public void deleteFlashRecord(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        if (!deviceAvailable()) return;
        if (downloading || tagBusy) { log("请等待当前下载或 TAG 操作结束"); return; }
        if (null == mSelectedIndexLeft && null == mSelectedIndexRight) {
            Toast.makeText(this, "请选择记录", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean isLeft = mSelectedIndexLeft != null;
        int index = isLeft ? mSelectedIndexLeft : mSelectedIndexRight;
        HeadsetManager.deleteFlashRecord(isLeft, index, new OnResultListener<FlashRecordDeleteEntity>() {
            @Override
            public void onResult(FlashRecordDeleteEntity flashRecordDeleteEntity) {
                log("Delete Flash Record Success: " + flashRecordDeleteEntity.toString());
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "删除成功", Toast.LENGTH_SHORT).show();
                    // 删除后刷新列表
                    getFlashRecordList(null);
                });
            }

            @Override
            public void onError(int code, String msg) {
                log("Delete Flash Record Error: code=" + code + ", msg=" + msg);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "删除失败: " + msg, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private String mFlashFilePath;
    public void downloadFlashRecord(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        if (!deviceAvailable()) return;
        if (tagBusy || downloading || HeadsetManager.isFusionRecordBusy()) { log("请先结束当前操作"); return; }
        //必须的！！！闪录进行中的时候，不能进行下载操作
        if (mCurrentState != null && mCurrentState.isRecording()) {
            Toast.makeText(this, "闪录进行中，无法下载", Toast.LENGTH_SHORT).show();
            return;
        }
        //todo 下载动作需要引导用户，把耳机都放在盒子中（防止放在外面，出现主副耳切换）；耳机不要双联其他设备（防止带宽不够）
        if (null == mSelectedIndexLeft && null == mSelectedIndexRight) {
            Toast.makeText(this, "请选择记录", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean isLeft = mSelectedIndexLeft != null;
        int index = isLeft ? mSelectedIndexLeft : mSelectedIndexRight;
        String filePath = mRecordPath + (isLeft ? "L_" : "R_") + index + ".pcm";
        File file = new File(filePath);
        File dir = file.getParentFile();
        if (!dir.exists()) {
            dir.mkdirs();
        }
        int sampleRate = 16000; // 默认采样率
        boolean isCallRecord = false;
        int totalDuration = 0;
        //从数据中找到对应的记录，获取其时长等信息
        if (isLeft) {
            for (FlashRecordEntity entity : mRecordListLeft) {
                if (entity.getIndex() == index) {
                    sampleRate = entity.getSampleRate();
                    isCallRecord = entity.isCallRecord();
                    totalDuration = entity.getLength();
                }
            }
        } else {
            for (FlashRecordEntity entity : mRecordListRight) {
                if (entity.getIndex() == index) {
                    sampleRate = entity.getSampleRate();
                    isCallRecord = entity.isCallRecord();
                    totalDuration = entity.getLength();
                }
            }
        }
        //这里需要传的是下载下来的pcm文件的长度，用于断点续传；如果不需要断点续传，每次传0即可
        int fileLength = (int) file.length();
        final int[] tmpFileLength = {fileLength};


        int finalTotalDuration = totalDuration;
        // 开始下载时，初始化进度条
        FlashRecordAdapter adapter = isLeft ? mAdapterLeft : mAdapterRight;
        adapter.setDownloadProgress(index, 0);
        
        downloading = true;
        HeadsetManager.downloadFlashRecord(isLeft, index, isCallRecord, sampleRate, fileLength, new OnResultListener<FlashRecordDownloadCheckEntity>() {
            @Override
            public void onResult(FlashRecordDownloadCheckEntity flashRecordDownloadEntity) {
                log("Download Flash Record Start Success: " + flashRecordDownloadEntity.toString());
                runOnUiThread(() -> {
                    if (flashRecordDownloadEntity.getErr() == 0) {
                        Toast.makeText(FlashRecordActivity.this, "下载检查成功", Toast.LENGTH_SHORT).show();
                    } else {
                        downloading = false;
                        Toast.makeText(FlashRecordActivity.this, "下载检查失败: err=" + flashRecordDownloadEntity.getErr(), Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void onError(int code, String msg) {
                downloading = false;
                log("Download Flash Record Error: code=" + code + ", msg=" + msg);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "下载检查失败: " + msg, Toast.LENGTH_SHORT).show();
                });
            }

        }, new OnResultListener<RecordDataEntity>() {
            @Override
            public void onResult(RecordDataEntity entity) {
                if (entity.isEnd()) {
                    downloading = false;
                    log("Download Flash Record Complete: totalBytes=" + tmpFileLength[0] + " path: " + filePath);
                    mFlashFilePath = filePath;
                    // 下载完成，隐藏进度条
                    runOnUiThread(() -> {
                        FlashRecordAdapter adapter = isLeft ? mAdapterLeft : mAdapterRight;
                        adapter.clearDownloadProgress();
                    });
                    //todo 下载完成后，需要校验文件的大小和时长是否正确，建议如果因为丢包（高干扰环境下，蓝牙丢包是比较常见现象）导致文件不完整，可以提示用户重新下载

                    //todo 下载完成后，需要删除这个记录，否则这个记录还在设备上；如果需要下载下一个记录，则需要等删除成功后，再去下载下一个
                } else {
                    byte[] bytes = entity.getAudioData();
                    //原始pcm数据（16k采样，16bit），转存到文件里面去
                    FileUtil.append(filePath, bytes);

                    tmpFileLength[0] += bytes.length;
                    int tmpDuration = tmpFileLength[0] / 32;
                    int progress = finalTotalDuration <= 0 ? 0 : Math.min(100, (int) (((float) tmpDuration / finalTotalDuration) * 100));
                    
                    // 更新进度条
                    runOnUiThread(() -> {
                        FlashRecordAdapter adapter = isLeft ? mAdapterLeft : mAdapterRight;
                        adapter.setDownloadProgress(index, progress);
                    });
                }
            }

            @Override
            public void onError(int code, String msg) {
                downloading = false;
                log("Download Flash Record Data Error: code=" + code + ", msg=" + msg);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "下载数据失败: " + msg, Toast.LENGTH_SHORT).show();
                    // 下载失败，隐藏进度条
                    FlashRecordAdapter adapter = isLeft ? mAdapterLeft : mAdapterRight;
                    adapter.clearDownloadProgress();
                });
            }
        });

    }

    public void cancelDownloadFlashRecord(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        downloading = false;
        HeadsetManager.cancelDownloadFlashRecord();
    }

    public void play(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        if (TextUtils.isEmpty(mFlashFilePath) || !new File(mFlashFilePath).isFile()
                || new File(mFlashFilePath).length() == 0) {
            log("没有可回听的录音，请先完成闪录下载");
            return;
        }
        stopPlayback();
        AudioTracker player = new AudioTracker();
        playback = player;
        if (!player.createAudioTrack(mFlashFilePath, false)) {
            stopPlayback();
            log("回听失败：播放器初始化失败");
            return;
        }
        findViewById(R.id.stop_playback).setVisibility(View.VISIBLE);
        log("开始回听 [" + mFlashFilePath + "]");
        player.start(() -> runOnUiThread(() -> {
            if (playback == player) {
                playback = null;
                findViewById(R.id.stop_playback).setVisibility(View.GONE);
            }
        }));
    }

    public void stopPlayback(View view) {
        stopPlayback();
        log("停止回听");
    }

    private void stopPlayback() {
        AudioTracker player = playback;
        playback = null;
        findViewById(R.id.stop_playback).setVisibility(View.GONE);
        if (player != null) player.stop();
    }

    public void clearFlashRecordLeft(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        if (!deviceAvailable()) return;
        if (downloading || tagBusy) { log("请等待当前下载或 TAG 操作结束"); return; }
        HeadsetManager.clearFlashRecord(true, new OnResultListener<FlashRecordDeleteEntity>() {
            @Override
            public void onResult(FlashRecordDeleteEntity result) {
                log("Clear Flash Record Left Success: " + result);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "清除左耳闪存记录成功", Toast.LENGTH_SHORT).show();
                    mRecordListLeft.clear();
                    mAdapterLeft.notifyDataSetChanged();
                    mSelectedIndexLeft = null;
                });
            }

            @Override
            public void onError(int code, String msg) {
                log("Clear Flash Record Left Error: code=" + code + ", msg=" + msg);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "清除左耳闪存记录失败: " + msg, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    public void clearFlashRecordRight(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        if (!deviceAvailable()) return;
        if (downloading || tagBusy) { log("请等待当前下载或 TAG 操作结束"); return; }
        HeadsetManager.clearFlashRecord(false, new OnResultListener<FlashRecordDeleteEntity>() {
            @Override
            public void onResult(FlashRecordDeleteEntity result) {
                log("Clear Flash Record Right Success: " + result);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "清除右耳闪存记录成功", Toast.LENGTH_SHORT).show();
                    mRecordListRight.clear();
                    mAdapterRight.notifyDataSetChanged();
                    mSelectedIndexRight = null;
                });
            }

            @Override
            public void onError(int code, String msg) {
                log("Clear Flash Record Right Error: code=" + code + ", msg=" + msg);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "清除右耳闪存记录失败: " + msg, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    public void clearFlashRecordAll(View view) {
        if (AuraDevice.isCase(deviceMac)) { log("当前盒子固件暂不支持闪录列表、下载及清除"); return; }
        if (!deviceAvailable()) return;
        if (downloading || tagBusy) { log("请等待当前下载或 TAG 操作结束"); return; }
        if (HeadsetManager.getConnectedDeviceType() == AuraDevice.EARBUDS) { clearAuraAudio(true, true); return; }
        HeadsetManager.clearFlashRecord(null, new OnResultListener<FlashRecordDeleteEntity>() {
            @Override
            public void onResult(FlashRecordDeleteEntity result) {
                log("Clear Flash Record All Success: " + result);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "清除所有闪存记录成功", Toast.LENGTH_SHORT).show();
                    mRecordListLeft.clear();
                    mAdapterLeft.notifyDataSetChanged();
                    mSelectedIndexLeft = null;
                    mRecordListRight.clear();
                    mAdapterRight.notifyDataSetChanged();
                    mSelectedIndexRight = null;
                });
            }

            @Override
            public void onError(int code, String msg) {
                log("Clear Flash Record All Error: code=" + code + ", msg=" + msg);
                runOnUiThread(() -> {
                    Toast.makeText(FlashRecordActivity.this, "清除所有闪存记录失败: " + msg, Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private void clearAuraAudio(boolean left, boolean thenRight) {
        HeadsetManager.clearFlashRecord(left, new OnResultListener<FlashRecordDeleteEntity>() {
            private void finish(String message, boolean success) {
                runOnUiThread(() -> {
                    log((left ? "左耳" : "右耳") + "闪录清空" + message);
                    if (success) {
                        if (left) { mRecordListLeft.clear(); mAdapterLeft.notifyDataSetChanged(); mSelectedIndexLeft = null; }
                        else { mRecordListRight.clear(); mAdapterRight.notifyDataSetChanged(); mSelectedIndexRight = null; }
                    }
                    if (thenRight && !isFinishing() && deviceAvailable()) clearAuraAudio(false, false);
                });
            }
            @Override public void onResult(FlashRecordDeleteEntity result) { finish("成功", true); }
            @Override public void onError(int code, String message) { finish("失败: " + message, false); }
        });
    }

    /**
     * 处理列表项点击事件
     * @param position 点击的位置
     * @param isLeft 是否为左耳列表
     */
    private void handleItemClick(int position, boolean isLeft) {
        List<FlashRecordEntity> recordList = isLeft ? mRecordListLeft : mRecordListRight;
        FlashRecordAdapter adapter = isLeft ? mAdapterLeft : mAdapterRight;

        if (recordList == null || recordList.isEmpty() || position >= recordList.size()) {
            return;
        }

        int listSize = recordList.size();
        // 判断是否为第一个或最后一个
        boolean isFirst = position == 0;
        boolean isLast = position == listSize - 1;

        // 如果点击的是已选中的项，则取消选中
        int currentSelectedPosition = adapter.getSelectedIndex();
        if (currentSelectedPosition == position) {
            if (isLeft) {
                mSelectedIndexLeft = null;
            } else {
                mSelectedIndexRight = null;
            }
            adapter.setSelectedIndex(-1);
            return;
        }

        // Aura supports deleting any record; legacy earbuds require the first or last.
        if (!AuraDevice.isAura(deviceMac) && !isFirst && !isLast) {
            Toast.makeText(this, "不能选中中间记录", Toast.LENGTH_SHORT).show();
            return;
        }

        // 选中该项
        FlashRecordEntity entity = recordList.get(position);
        int recordIndex = entity.getIndex(); // 记录的index属性

        if (isLeft) {
            mSelectedIndexLeft = recordIndex;
            // 清除右耳的选中状态
            if (mSelectedIndexRight != null) {
                mSelectedIndexRight = null;
                mAdapterRight.clearSelection();
            }
        } else {
            mSelectedIndexRight = recordIndex;
            // 清除左耳的选中状态
            if (mSelectedIndexLeft != null) {
                mSelectedIndexLeft = null;
                mAdapterLeft.clearSelection();
            }
        }

        // 设置adapter的选中状态（使用列表位置）
        adapter.setSelectedIndex(position);
    }

    private void log(String msg) {
        log(false, msg + "\n");
    }

    private void log(boolean clear, String msg) {

        DemoLog.d(TAG, msg);
        runOnUiThread(() -> {
            CharSequence text = mResultTv.getText();
            if (clear) {
                text = "";
            }
            String s;
            if (TextUtils.isEmpty(text)) {
                s = msg;
            } else {
                s = text + msg;
            }
            mResultTv.setText(s);
            mScrollView.postDelayed(() -> mScrollView.fullScroll(ScrollView.FOCUS_DOWN), 200);
        });
    }
}
