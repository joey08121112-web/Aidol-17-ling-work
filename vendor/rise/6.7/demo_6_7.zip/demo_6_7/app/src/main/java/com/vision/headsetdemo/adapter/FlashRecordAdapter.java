package com.vision.headsetdemo.adapter;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.vision.headset.sdk.entity.FlashRecordEntity;
import com.vision.headsetdemo.R;

import java.util.List;

/**
 * Copyright (C), Vision Intelligence
 * FileName: FlashRecordAdapter
 * Author: 毛神
 * Date: 2025/11/5 13:57
 * Description: FlashRecord列表适配器
 * History:
 * 作者姓名 修改时间 版本号 描述
 */
public class FlashRecordAdapter extends BaseAdapter {
    private List<FlashRecordEntity> mRecordList;
    private LayoutInflater mInflater;
    private int mSelectedIndex = -1; // 选中的索引，-1表示未选中
    private int mDownloadingIndex = -1; // 正在下载的记录index（记录的index属性，不是position）
    private int mDownloadProgress = 0; // 下载进度 0-100

    public FlashRecordAdapter(Context context, List<FlashRecordEntity> recordList) {
        mRecordList = recordList;
        mInflater = LayoutInflater.from(context);
    }

    /**
     * 设置选中的索引
     */
    public void setSelectedIndex(int index) {
        int oldIndex = mSelectedIndex;
        mSelectedIndex = index;
        // 只刷新变化的项，避免整个列表刷新
        if (oldIndex != -1 && oldIndex != index) {
            notifyDataSetChanged();
        } else if (mSelectedIndex != -1) {
            notifyDataSetChanged();
        }
    }

    /**
     * 获取选中的索引
     */
    public int getSelectedIndex() {
        return mSelectedIndex;
    }

    /**
     * 清除选中状态
     */
    public void clearSelection() {
        if (mSelectedIndex != -1) {
            int oldIndex = mSelectedIndex;
            mSelectedIndex = -1;
            notifyDataSetChanged();
        }
    }

    /**
     * 设置下载进度
     * @param recordIndex 记录的index属性
     * @param progress 进度 0-100
     */
    public void setDownloadProgress(int recordIndex, int progress) {
        mDownloadingIndex = recordIndex;
        mDownloadProgress = progress;
        // 找到对应的position并更新
        if (mRecordList != null) {
            for (int i = 0; i < mRecordList.size(); i++) {
                FlashRecordEntity entity = mRecordList.get(i);
                if (entity != null && entity.getIndex() == recordIndex) {
                    notifyDataSetChanged();
                    break;
                }
            }
        }
    }

    /**
     * 清除下载进度
     */
    public void clearDownloadProgress() {
        if (mDownloadingIndex != -1) {
            mDownloadingIndex = -1;
            mDownloadProgress = 0;
            notifyDataSetChanged();
        }
    }

    @Override
    public int getCount() {
        return mRecordList != null ? mRecordList.size() : 0;
    }

    @Override
    public FlashRecordEntity getItem(int position) {
        if (mRecordList != null && position >= 0 && position < mRecordList.size()) {
            return mRecordList.get(position);
        }
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            // 如果convertView为null，说明需要创建新的视图
            if (mInflater == null && parent != null) {
                mInflater = LayoutInflater.from(parent.getContext());
            }
            if (mInflater == null) {
                return null;
            }
            convertView = mInflater.inflate(R.layout.item_flash_record, parent, false);
            holder = new ViewHolder();
            holder.tvIsLeft = convertView.findViewById(R.id.tv_is_left);
            holder.tvIndex = convertView.findViewById(R.id.tv_index);
            holder.tvPhoneNum = convertView.findViewById(R.id.tv_phone_num);
            holder.tvLength = convertView.findViewById(R.id.tv_length);
            holder.tvIsCallRecord = convertView.findViewById(R.id.tv_is_call_record);
            holder.tvSampleType = convertView.findViewById(R.id.tv_sample_type);
            holder.progressBar = convertView.findViewById(R.id.progress_bar);
            convertView.setTag(holder);
        } else {
            // 复用已有的视图
            holder = (ViewHolder) convertView.getTag();
        }

        // 获取当前位置的数据
        FlashRecordEntity entity = getItem(position);
        if (entity != null) {
            // 设置选中状态的背景
            if (mSelectedIndex == position) {
                convertView.setBackgroundResource(R.drawable.item_selected_background);
            } else {
                // 恢复默认背景
                convertView.setBackgroundResource(R.drawable.item_normal_background);
            }

            // 设置isLeft属性
            boolean isLeft = entity.isLeft();
            holder.tvIsLeft.setText(entity.isCaseRecord() ? "盒子" : isLeft ? "左耳" : "右耳");
            Context context = convertView.getContext();
            holder.tvIsLeft.setTextColor(isLeft ? context.getResources().getColor(R.color.teal_700) : context.getResources().getColor(R.color.purple_700));

            // 设置index属性
            int index = entity.getIndex();
            holder.tvIndex.setText("编号: " + index);
            if (entity.getPreviousSegment() != null || entity.getNextSegment() != null || entity.isRelayMetadataInvalid()) {
                StringBuilder relay = new StringBuilder(holder.tvIndex.getText());
                if (entity.getPreviousSegment() != null) relay.append("\n前段 ").append(entity.getPreviousSegment().getEar() == 1 ? "左" : "右").append("/").append(entity.getPreviousSegment().getFileId());
                if (entity.getNextSegment() != null) relay.append("\n后段 ").append(entity.getNextSegment().getEar() == 1 ? "左" : "右").append("/").append(entity.getNextSegment().getFileId());
                if (entity.isRelayMetadataInvalid()) relay.append("\n链录引用无效");
                holder.tvIndex.setText(relay);
            }

            // 设置phoneNum属性
            String phoneNum = entity.getPhoneNum();
            holder.tvPhoneNum.setText("电话: " + (TextUtils.isEmpty(phoneNum) ? "无" : phoneNum));

            // 设置length属性
            int length = entity.getLength();
            holder.tvLength.setText(" " + (length / 1000) + "秒");

            // 设置isCallRecord属性
            boolean isCallRecord = entity.isCallRecord();
            if (isCallRecord) {
                holder.tvIsCallRecord.setText("通话录音");
            } else {
                holder.tvIsCallRecord.setText("线下录音");
            }

            // 设置sampleType属性
            int sampleRate = entity.getSampleRate();
            String sampleTypeText = "采样率: " + sampleRate;
            holder.tvSampleType.setText(sampleTypeText);

            // 设置下载进度
            int recordIndex = entity.getIndex();
            if (mDownloadingIndex == recordIndex) {
                holder.progressBar.setVisibility(View.VISIBLE);
                holder.progressBar.setProgress(mDownloadProgress);
            } else {
                holder.progressBar.setVisibility(View.GONE);
                holder.progressBar.setProgress(0);
            }
        }

        return convertView;
    }

    /**
     * ViewHolder模式，提高列表性能
     */
    private static class ViewHolder {
        TextView tvIsLeft;
        TextView tvIndex;
        TextView tvPhoneNum;
        TextView tvLength;
        TextView tvIsCallRecord;
        TextView tvSampleType;
        ProgressBar progressBar;
    }
}
