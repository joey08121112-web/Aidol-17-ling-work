package com.vision.headsetdemo.util;

import android.util.Log;

/**
 * Copyright (C), Vision Intelligence
 * FileName: DebugLog
 * Author: 毛神
 * Date: 2024/1/16 9:46
 * Description:
 * History:
 * 作者姓名 修改时间 版本号 描述
 */
public class DemoLog {
    private static final String TAG_PRE = "Demo_";

    public static void d(String tag, String msg) {
        Log.d(TAG_PRE + tag, msg);
    }

    public static void v(String tag, String msg) {
        Log.v(TAG_PRE + tag, msg);
    }

    public static void w(String tag, String msg) {
        Log.w(TAG_PRE + tag, msg);
    }

    public static void i(String tag, String msg) {
        Log.i(TAG_PRE + tag, msg);
    }

    public static void e(String tag, Throwable t) {
        Log.e(TAG_PRE + tag, "err ", t);
    }

    public static void e(String tag, String msg, Throwable t) {
        Log.e(TAG_PRE + tag, msg, t);
    }
}
