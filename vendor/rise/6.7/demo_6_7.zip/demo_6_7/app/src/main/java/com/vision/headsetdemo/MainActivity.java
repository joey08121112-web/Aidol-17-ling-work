package com.vision.headsetdemo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ScrollView;
import android.widget.Button;
import com.vision.headset.sdk.OnAuraRecordListener;
import com.vision.headset.sdk.util.AuraDevice;
import android.widget.TextView;
import android.widget.Toast;


import com.vision.headset.sdk.HeadsetErrorCode;
import com.vision.headset.sdk.HeadsetManager;
import com.vision.headset.sdk.OnDialogListener;
import com.vision.headset.sdk.OnConnectChangeListener;
import com.vision.headset.sdk.OnResultListener;
import com.vision.headset.sdk.entity.PowerEntity;
import com.vision.headset.sdk.entity.RecordDataEntity;
import com.vision.headset.sdk.entity.SNEntity;
import com.vision.headset.sdk.enums.GaiaConnectStatus;
import com.vision.headset.sdk.util.AudioTracker;
import com.vision.headsetdemo.util.DemoLog;
import com.vision.headsetdemo.util.FileUtil;

import java.io.File;


/**
 * Copyright (C), Vision Intelligence
 * FileName: MainActivity
 * Author: 毛神
 * Date: 2024/6/20 19:36
 * Description: demo页面
 * History:
 * 调整为通话录音示例
 */
public class MainActivity extends Activity {
    private static final String TAG = "MainActivity";
    private ScrollView mScrollView;
    private TextView mResultTv;

    public String mRecordPath = "";

    private boolean isBudsInDialog = false;
    private boolean liveRecording;
    private boolean fusionOwned;
    private boolean disconnecting;
    private boolean caseConnecting;
    private boolean caseMacQuerying;
    private AudioTracker playback;
    private final OnConnectChangeListener connectionListener = new OnConnectChangeListener() {
        @Override public void onConnectChange(String mac, GaiaConnectStatus state, String info) {
            log("连接状态: " + mac + " " + state + " " + info);
            runOnUiThread(() -> {
                if (state == GaiaConnectStatus.DISCONNECTED) liveRecording = false;
                if (state == GaiaConnectStatus.DISCONNECTED || state == GaiaConnectStatus.CONNECT_ERROR) caseConnecting = false;
                if (state == GaiaConnectStatus.DISCONNECTING) disconnecting = true;
                else disconnecting = false;
                updateControls();
            });
        }
        @Override public void onConnectReady(String mac) {
            log("设备已连接: " + mac);
            runOnUiThread(() -> { caseConnecting = false; mRecordPath = getExternalCacheDir().getAbsolutePath() + "/record_" + mac.replace(":", ""); updateControls(); });
        }
        @Override public void onAuraCaseAddressCached(String earbudsMac, String caseMac) {
            runOnUiThread(() -> updateControls());
        }
    };

    private void updateControls() {
        boolean ready = HeadsetManager.isDeviceReady();
        boolean connected = HeadsetManager.isDeviceConnected();
        Button connectButton = findViewById(R.id.connect_device);
        connectButton.setText(connected || disconnecting ? "断开连接" : "连接耳机");
        connectButton.setEnabled(!disconnecting && !caseConnecting);
        int model = HeadsetManager.getConnectedDeviceType();
        boolean aura = model == AuraDevice.EARBUDS, box = model == AuraDevice.CASE;
        findViewById(R.id.get_case_mac).setVisibility(aura && ready && !disconnecting ? View.VISIBLE : View.GONE);
        findViewById(R.id.get_case_mac).setEnabled(!caseMacQuerying);
        findViewById(R.id.connect_case).setVisibility(!connected && !disconnecting ? View.VISIBLE : View.GONE);
        findViewById(R.id.connect_case).setEnabled(!connected && !disconnecting && !caseConnecting);
        ((TextView) findViewById(R.id.device_state)).setText(ready ? (aura ? "Aura 耳机" : box ? "Aura 盒子" : "耳机") + " · " + HeadsetManager.getConnectedDeviceMac() : "未连接设备");
        findViewById(R.id.fusion_controls).setVisibility(aura && ready ? View.VISIBLE : View.GONE);
        findViewById(R.id.aura_key_test).setVisibility(aura && ready && !disconnecting ? View.VISIBLE : View.GONE);
        findViewById(R.id.call_controls).setVisibility(!aura && !box ? View.VISIBLE : View.GONE);
        findViewById(R.id.dual_playback).setVisibility(!box ? View.VISIBLE : View.GONE);
        findViewById(R.id.volume_plus_controls).setVisibility(!box ? View.VISIBLE : View.GONE);
        findViewById(R.id.live_controls).setVisibility(!aura ? View.VISIBLE : View.GONE);
        findViewById(R.id.play_live).setVisibility(!aura ? View.VISIBLE : View.GONE);
        ((Button) findViewById(R.id.start_live)).setText(box ? "开始盒子录音" : "开始线下录音");
        ((Button) findViewById(R.id.stop_live)).setText(box ? "停止盒子录音" : "结束线下录音");
        ((Button) findViewById(R.id.play_live)).setText(box ? "回听盒子录音" : "回听线下录音");
        findViewById(R.id.start_live).setEnabled(ready && !liveRecording);
        findViewById(R.id.stop_live).setEnabled(ready && liveRecording);
        findViewById(R.id.start_fusion).setEnabled(ready && !HeadsetManager.isFusionRecordBusy());
        findViewById(R.id.stop_fusion).setEnabled(ready && HeadsetManager.isFusionRecordBusy());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mScrollView = findViewById(R.id.scroll_view);
        mResultTv = findViewById(R.id.result_tv);
        mRecordPath = getExternalCacheDir().getAbsolutePath() + "/record";

        ///
        //初始化
        HeadsetManager.init(getApplicationContext(), new Runnable() {
            @Override
            public void run() {
                log("HeadsetManager 初始化完成");
                connectEarbuds();
            }
        });
        HeadsetManager.registerDialogListener(new OnDialogListener() {

            @Override
            public void onDialogActive() {
                log("进入通话状态");
                isBudsInDialog = true;
            }

            @Override
            public void onDialogNum(String phoneNum) {
                log("电话号码: " + phoneNum);
            }

            @Override
            public void onDialogInActive() {
                log("结束通话状态");
                isBudsInDialog = false;
            }
        });
    }

    public void scanAndConnect(View view) {
        if (disconnecting || caseConnecting) return;
        if (HeadsetManager.isDeviceConnected()) {
            log("断开当前设备");
            HeadsetManager.disconnectDevice();
        } else {
            connectEarbuds();
        }
    }
    private void connectEarbuds() {
        if (liveRecording || HeadsetManager.isFusionRecordBusy()) { log("请先停止录音再切换设备"); return; }
        if (!hasConnectionPermissions(0)) return;
        if (!HeadsetManager.isBluetoothEnabled()) { Toast.makeText(this, "请先打开手机蓝牙", Toast.LENGTH_SHORT).show(); return; }
        log("扫描并连接耳机");
        HeadsetManager.switchDevice(getApplicationContext(), false, connectionListener);
    }
    public void scanAndConnectCase(View view) { connectCase(); }
    private void connectCase() {
        if (disconnecting || caseConnecting) return;
        if (liveRecording || HeadsetManager.isFusionRecordBusy()) { log("请先停止录音再切换设备"); return; }
        if (HeadsetManager.isDeviceConnected()) return;
        String mac = HeadsetManager.getAuraCaseAddress();
        if (mac == null) {
            String message = "请先连接耳机获取盒子mac地址";
            log(message);
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!hasConnectionPermissions(1)) return;
        if (!HeadsetManager.isBluetoothEnabled()) { Toast.makeText(this, "请先打开手机蓝牙", Toast.LENGTH_SHORT).show(); return; }
        caseConnecting = true;
        updateControls();
        log("BLE 扫描并连接指定盒子: " + mac);
        HeadsetManager.switchDevice(getApplicationContext(), true, connectionListener);
    }
    private boolean hasConnectionPermissions(int requestCode) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED
                    || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT}, requestCode); return false;
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, requestCode); return false;
        }
        return true;
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if ((requestCode == 0 || requestCode == 1) && results.length > 0) {
            for (int result : results) if (result != PackageManager.PERMISSION_GRANTED) { log("需要蓝牙权限才能连接设备"); return; }
            if (requestCode == 1) connectCase(); else connectEarbuds();
        }
    }

    public void startFusionRecord(View view) {
        if (!HeadsetManager.isDeviceReady() || HeadsetManager.getConnectedDeviceType() != AuraDevice.EARBUDS || HeadsetManager.isFusionRecordBusy()) return;
        String mic = mRecordPath + "_mic.pcm", speaker = mRecordPath + "_spk.pcm";
        new File(mic).delete(); new File(speaker).delete();
        fusionOwned = true;
        HeadsetManager.startFusionRecord(new OnAuraRecordListener() {
            @Override public void onState(String state, int scene) {
                String sceneText = scene == 0 ? "通话" : scene == 1 ? "媒体播放" : scene == 2 ? "媒体空闲" : "等待音频";
                String stateText = "starting".equals(state) ? "正在开始" : "recording".equals(state) ? "录音中" : "stopping".equals(state) ? "正在停止" : "已停止";
                log("融合录音: " + stateText + "，场景: " + sceneText);
                if ("idle".equals(state)) fusionOwned = false;
                runOnUiThread(() -> {
                    updateControls();
                    ((TextView) findViewById(R.id.device_state)).append(" · " + stateText + " · " + sceneText);
                });
            }
            @Override public void onResult(RecordDataEntity data) { FileUtil.append(data.isSpk() ? speaker : mic, data.getAudioData()); }
            @Override public void onError(int code, String message) { fusionOwned = false; log("融合录音失败: " + message); runOnUiThread(() -> updateControls()); }
        });
    }
    public void stopFusionRecord(View view) { HeadsetManager.stopFusionRecord(); }

    @Override protected void onResume() { super.onResume(); if (mResultTv != null) updateControls(); }
    @Override protected void onStop() {
        stopPlayback();
        super.onStop();
    }
    @Override protected void onDestroy() {
        stopPlayback();
        if (fusionOwned) HeadsetManager.stopFusionRecord();
        if (liveRecording) HeadsetManager.stopLiveRecord();
        HeadsetManager.registerDialogListener(null);
        HeadsetManager.destroy();
        super.onDestroy();
    }

    private void log(String msg) {
        log(false, msg + "\n\n");
    }

    private void log(boolean clear, String msg) {

        DemoLog.d(TAG, msg);
        runOnUiThread(() -> {
            CharSequence text = mResultTv.getText();
            if (clear) {
                text = "";
            }
            String s;
            if (TextUtils.isEmpty(text)) {
                s = msg;
            } else {
                s = text + msg;
            }
            mResultTv.setText(s);
            mScrollView.postDelayed(() -> mScrollView.fullScroll(ScrollView.FOCUS_DOWN), 200);
        });
    }

    ///region version 4.0 add
    public void startCallRecord(View view) {
        if (HeadsetManager.getConnectedDeviceType() == AuraDevice.EARBUDS) { startFusionRecord(view); return; }
        //耳机只有出于通话状态，才能启动录音；比如说飞书软件正在通话，如果选择的通道不是耳机，而是手机扬声器，则耳机不会进入通话状态
        if (!isBudsInDialog) {
            log("耳机不在通话状态，无法启动录音");
            Toast.makeText(this, "耳机不在通话状态，无法启动录音", Toast.LENGTH_SHORT).show();
            return;
        }
        String pathSpk = mRecordPath + "_spk.pcm";
        File file = new File(pathSpk);
        if (file.exists()) {
            file.delete();
        }
        String pathMic = mRecordPath + "_mic.pcm";
        file = new File(pathMic);
        if (file.exists()) {
            file.delete();
        }
        log("扬声器录音地址 = [" + pathSpk + "]\n麦克风录音地址 = [" + pathMic + "]");
        Toast.makeText(this, pathSpk + "\n" + pathMic, Toast.LENGTH_SHORT).show();
        HeadsetManager.setCallRecordListener(new OnResultListener<RecordDataEntity>() {
            @Override
            public void onResult(RecordDataEntity entity) {
                byte[] bytes = entity.getAudioData();
                if (entity.isSpk()) {
                    //原始pcm数据（16k采样，16bit），转存到文件里面去
                    FileUtil.append(pathSpk, bytes);
                } else {
                    FileUtil.append(pathMic, bytes);
                }
            }

            @Override
            public void onError(int code, String msg) {
                log("录音失败 code = [" + code + "], msg = [" + msg + "]");
            }
        });
        log("开始录音");
        HeadsetManager.startCallRecord();
    }

    public void stopCallRecord(View view) {
        log("停止录音");
        if (HeadsetManager.getConnectedDeviceType() == AuraDevice.EARBUDS) HeadsetManager.stopFusionRecord();
        else HeadsetManager.stopCallRecord();
    }

    public void playMic(View view) {
        playRecording(mRecordPath + "_mic.pcm", view);
    }

    public void playSpk(View view) {
        playRecording(mRecordPath + "_spk.pcm", view);
    }

    public void startLiveRecord(View view) {
        if (liveRecording || !HeadsetManager.isDeviceReady()) { log("请先连接设备，并等待当前录音结束"); return; }
        if (HeadsetManager.getConnectedDeviceType() == AuraDevice.EARBUDS) { startFusionRecord(view); return; }
        if (isBudsInDialog && HeadsetManager.getConnectedDeviceType() != AuraDevice.CASE) {
            log("耳机在通话状态，无法启动录音");
            Toast.makeText(this, "耳机不在通话状态，无法启动录音", Toast.LENGTH_SHORT).show();
            return;
        }
        String pathLive = mRecordPath + "_live.pcm";
        File file = new File(pathLive);
        if (file.exists()) {
            file.delete();
        }
        log("线下录音地址 = [" + pathLive + "]");
        Toast.makeText(this, pathLive, Toast.LENGTH_SHORT).show();
        HeadsetManager.setLiveRecordListener(new OnResultListener<RecordDataEntity>() {
            @Override
            public void onResult(RecordDataEntity entity) {
                if (entity.isEnd()) {
                    liveRecording = false;
                    runOnUiThread(() -> updateControls());
                    return;
                }
                byte[] bytes = entity.getAudioData();
                //原始pcm数据（16k采样，16bit），转存到文件里面去
                if (bytes != null) FileUtil.append(pathLive, bytes);
            }

            @Override
            public void onError(int code, String msg) {
                liveRecording = false;
                runOnUiThread(() -> updateControls());
                if (HeadsetErrorCode.ERROR_LIVE_RECORD_FORCE_STOP_BY_CALL == code) {
                    log("线下录音失败 被电话打断");
                } else {
                    log("线下录音失败 code = [" + code + "], msg = [" + msg + "]");
                }
            }
        });
        liveRecording = true; updateControls();
        log("开始录音");
        HeadsetManager.startLiveRecord();
    }

    public void stopLiveRecord(View view) {
        liveRecording = false; updateControls();
        log("停止录音");
        HeadsetManager.stopLiveRecord();
    }

    public void playLive(View view) {
        playRecording(mRecordPath + "_live.pcm", view);
    }

    private void playRecording(String path, View source) {
        File file = new File(path);
        if (!file.isFile() || file.length() == 0) {
            log("没有可回听的录音，请先完成录音");
            return;
        }
        stopPlayback();
        AudioTracker player = new AudioTracker();
        playback = player;
        if (!player.createAudioTrack(path, false)) {
            stopPlayback();
            log("回听失败：播放器初始化失败");
            return;
        }
        View stopButton = findViewById(R.id.stop_playback);
        ViewGroup row = (ViewGroup) source.getParent();
        ((ViewGroup) stopButton.getParent()).removeView(stopButton);
        row.addView(stopButton, row.indexOfChild(source) + 1);
        stopButton.setVisibility(View.VISIBLE);
        log("开始回听 [" + path + "]");
        player.start(() -> runOnUiThread(() -> {
            // 切换回听后，旧播放器的结束通知不能隐藏新播放器的停止按钮。
            if (playback == player) {
                playback = null;
                findViewById(R.id.stop_playback).setVisibility(View.GONE);
            }
        }));
    }

    public void stopPlayback(View view) {
        stopPlayback();
        log("停止回听");
    }

    private void stopPlayback() {
        AudioTracker player = playback;
        playback = null;
        findViewById(R.id.stop_playback).setVisibility(View.GONE);
        if (player != null) player.stop();
    }
    ///endregion


    ///region  5.5 闪录

    public void gotoFlashRecordPage(View view) {
        Intent intent = new Intent(this, FlashRecordActivity.class);
        startActivity(intent);
    }

    public void gotoAuraKeyTestPage(View view) {
        if (!HeadsetManager.isDeviceReady() || HeadsetManager.getConnectedDeviceType() != AuraDevice.EARBUDS) return;
        startActivity(new Intent(this, AuraKeyTestActivity.class));
    }
    ///endregion

    ///region  5.7 基础信息

    public void getSerialNumber(View view) {
        HeadsetManager.getSN(new OnResultListener<SNEntity>() {
            @Override
            public void onResult(SNEntity snEntity) {
                String left = snEntity.getLeft();
                String right = snEntity.getRight();
                String box = snEntity.getBox();

                log("获取耳机SN成功 [" + left + ", " + right + ", " + box + "]");
                //耳机型号，取SN的前三位
                if (!TextUtils.isEmpty(left) && left.length() >= 3) {
                    log("左耳机型号 = [" + left.substring(0, 3) + "]");
                }
                if (!TextUtils.isEmpty(right) && right.length() >= 3) {
                    log("右耳机型号 = [" + right.substring(0, 3) + "]");
                }
                if (!TextUtils.isEmpty(box) && box.length() >= 3) {
                    log("盒子型号 = [" + box.substring(0, 3) + "]");
                }
            }

            @Override
            public void onError(int code, String msg) {
                log("获取耳机SN失败 code = [" + code + "], msg = [" + msg + "]");
            }
        });
    }

    public void getCaseMac(View view) {
        if (caseMacQuerying) return;
        if (!HeadsetManager.isDeviceReady() || HeadsetManager.getConnectedDeviceType() != AuraDevice.EARBUDS) {
            log("请先连接 Aura 耳机");
            updateControls();
            return;
        }
        caseMacQuerying = true;
        updateControls();
        log("开始获取 Aura 盒子 MAC 地址");
        HeadsetManager.getAuraCaseMac(new OnResultListener<String>() {
            @Override public void onResult(String mac) {
                runOnUiThread(() -> {
                    caseMacQuerying = false;
                    log("获取盒子 MAC 地址成功 [" + mac + "]，已缓存");
                    updateControls();
                });
            }
            @Override public void onError(int code, String message) {
                runOnUiThread(() -> {
                    caseMacQuerying = false;
                    log("获取盒子 MAC 地址失败 code = [" + code + "], msg = [" + message + "]");
                    updateControls();
                });
            }
        });
    }

    public void getPower(View view) {
        //调用一次后，后续耳机电量有变化，都会通知app
        HeadsetManager.getPowerPositionConnection(new OnResultListener<PowerEntity>() {
            @Override
            public void onResult(PowerEntity powerEntity) {
                int left = powerEntity.getLeftPowerValue();
                int right = powerEntity.getRightPowerValue();
                //如果耳机不在盒子中，无法获取到盒子电量，需要业务侧做缓存
                int box = powerEntity.getCasePowerValue();

                log("获取耳机电量成功 左耳 = [" + left + "%], 右耳 = [" + right + "%], 盒子 = [" + box + "%]");
                log("耳机其他信息 = [" + powerEntity + "]");
            }

            @Override
            public void onError(int code, String msg) {

            }
        });
    }
    ///endregion


    ///region 5.8 音量增强 注意！！！！仅AIR2有此功能！！！
    public void queryVolumePlus(View view) {
        HeadsetManager.getVolumePlusSwitch(new OnResultListener<Boolean>() {
            @Override
            public void onResult(Boolean entity) {
                boolean isOpen = entity;
                log("查询音量增强开关状态成功 isOpen = [" + isOpen + "]");
            }

            @Override
            public void onError(int code, String msg) {
                log("查询音量增强开关状态失败 code = [" + code + "], msg = [" + msg + "]");
            }
        });

    }

    public void openVolumePlus(View view) {
        HeadsetManager.setVolumePlusSwitch(true);
        log("打开音量增强 ");
    }

    public void closeVolumePlus(View view) {
        HeadsetManager.setVolumePlusSwitch(false);
        log("关闭音量增强 ");
    }
    ///endregion
}
