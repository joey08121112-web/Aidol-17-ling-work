package com.vision.headsetdemo.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Copyright (C), Vision Intelligence
 * FileName: FileUtil
 * Author: 毛神
 * Date: 2024/3/14 19:05
 * Description:
 * History:
 * 作者姓名 修改时间 版本号 描述
 */
public class FileUtil {

    public static void append(String path, byte[] data) {
        // 打开文件
        File file = new File(path);
        File dir = file.getParentFile();
        if (!dir.exists()) {
            dir.mkdirs();
        }
        try {
            // 创建文件输出流
            FileOutputStream fos = new FileOutputStream(file, true);
            try {
                // 写入数据
                fos.write(data);
            } finally {
                // 关闭文件输出流
                fos.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
